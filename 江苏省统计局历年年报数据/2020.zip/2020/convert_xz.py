# -*- coding: utf-8 -*-
"""2020 乡镇基本情况(nj22) 按13地级市汇总转换"""
import sys, os, re
sys.path.insert(0,'2020/scripts')
from html2xlsx_lib import *
from openpyxl import Workbook

# 地级市码 -> 名称
CITY = {'01':'南京','02':'无锡','03':'徐州','04':'常州','05':'苏州','06':'南通',
'07':'连云港','08':'淮安','09':'盐城','10':'扬州','11':'镇江','12':'泰州','13':'宿迁'}

# 页面码 -> 地区名 (从nj22.htm抓取)
# 建立 code -> 市县名
def get_links():
    raw=open('2020/html/nj22.htm',encoding='utf-8',errors='ignore').read()
    # nj22.htm 是gbk? 实际页面列表在2020/html? 不, nj22.htm是篇目列表页, 需单独下载
    return {}

# 直接手工映射（从上一输出）
CODES = {
 '2201nj':'南京市','2202wx':'市辖区','2202jy':'江阴市','2202yx':'宜兴市',
 '2203xz':'市辖区','2203fx':'丰县','2203px':'沛县','2203sn':'睢宁县','2203xy':'新沂市','2203pz':'邳州市',
 '2204cz':'市辖区','2204ly':'溧阳市',
 '2205sz':'市辖区','2205cs':'常熟市','2205zjg':'张家港市','2205ks':'昆山市','2205tc':'太仓市',
 '2206nt':'市辖区','2206rd':'如东县','2206qd':'启东市','2206rg':'如皋市','2206hm':'海门市','2206ha':'海安市',
 '2207lyg':'市辖区','2207dh':'东海县','2207gy':'灌云县','2207gn':'灌南县',
 '2208ha':'市辖区','2208ls':'涟水县','2208xy':'盱眙县','2208jh':'金湖县',
 '2209yc':'市辖区','2209xs':'响水县','2209bh':'滨海县','2209fn':'阜宁县','2209sy':'射阳县','2209jh':'建湖县','2209dt':'东台市',
 '2210yz':'市辖区','2210by':'宝应县','2210yzhen':'仪征市','2210gy':'高邮市',
 '2211zj':'市辖区','2211dy':'丹阳市','2211yz':'扬中市','2211jr':'句容市',
 '2212tz':'市辖区','2212xh':'兴化市','2212jj':'靖江市','2212tx':'泰兴市',
 '2213sq':'市辖区','2213sy':'沭阳县','2213syang':'泗阳县','2213sh':'泗洪县',
}

# 存/code缓存到文件供转换用
import json
json.dump(CODES, open('2020/scripts/xz_codes.json','w'), ensure_ascii=False)

# 地级市码 -> 页面codes
city_pages={}
for code,name in CODES.items():
    city_code=code[2:4]  # 2201nj -> '01'
    city_pages.setdefault(city_code,[]).append((code,name))

for city_code, items in sorted(city_pages.items()):
    # city_code 是 '2201' 的 '01'? 实际 code[:2]='22', 要用code[2:4]即市码
    city_name=CITY.get(city_code, city_code)
    wb=Workbook(); wb.remove(wb.active)
    for code,name in sorted(items, key=lambda x:x[1]):
        f=f'2020/html/nj{code}.htm'
        if not os.path.exists(f):
            print(f"缺失 {f}"); continue
        rows=read_cells(f)
        # sheet名用 市县名
        ws=wb.create_sheet(name[:31])
        write_sheet(ws,rows,city_code)
    if len(wb.sheetnames)==0:
        wb.create_sheet('数据')
    out=f'2020/乡镇基本情况-{city_name}.xlsx'
    wb.save(out)
    print(f"{city_name}市: {len(wb.sheetnames)} sheets -> {out}")
print("\n乡镇转换完成")

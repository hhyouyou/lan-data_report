# -*- coding: utf-8 -*-
"""2020年鉴 HTML -> xlsx 转换核心库"""
import re, os, glob, openpyxl
from openpyxl.utils import get_column_letter

def read_cells(path):
    """读HTML表格所有行，返回行列表(每行是cell列表)"""
    raw=open(path,encoding='gbk',errors='ignore').read()
    rows=re.findall(r'<tr[^>]*>(.*?)</tr>',raw,re.S)
    out=[]
    for r in rows:
        cells=re.findall(r'<t[dh][^>]*>(.*?)</t[dh]>',r,re.S)
        clean=[re.sub(r'<br[^>]*>','\n',c)
                 .replace('\xa0',' ').replace('&nbsp;','')
                 .replace('\u3000',' ')
              for c in cells]
        clean=[re.sub(r'<[^>]+>','',c) for c in clean]
        clean=[re.sub(r'\n+','\n',c).strip() for c in clean]
        out.append(clean)
    return out

def extract_title(rows, njnum):
    """从行列表提取sheet标题"""
    for cells in rows:
        cells=[c for c in cells if c]
        if not cells: continue
        first=cells[0]
        if re.match(r'^[0-9]+-[0-9]+', first):
            t=re.sub(r'[（(]\s*\d{4}年[^）)]*[）)]','',first)
            t=re.sub(r'\s{2,}',' ',t).strip().rstrip('，,、')
            return t
    return None

def sheet_title_for_page(rows, seq, njnum):
    """根据页面类型确定sheet名"""
    for cells in rows:
        cells=[c for c in cells if c]
        if not cells: continue
        first=cells[0]
        if re.match(r'^[0-9]+-[0-9]+', first):
            t=re.sub(r'[（(]\s*\d{4}年[^）)]*[）)]','',first)
            t=re.sub(r'\s{2,}',' ',t).strip().rstrip('，,、')
            return t
        if '自然概况' in first: return '自然概况'
        if '从数字看' in first: return first.replace('\n','').strip()[:40]
    return None

def write_sheet(ws, rows, njnum):
    """把解析出的行写入worksheet"""
    r=1
    for cells in rows:
        for c_idx,val in enumerate(cells):
            if val!='':
                ws.cell(row=r,column=c_idx+1,value=val)
        r+=1
    return r

def normalize_title(s):
    s=re.sub(r'\s+',' ',s).strip()
    s=re.sub(r'[　]+','',s)
    return s

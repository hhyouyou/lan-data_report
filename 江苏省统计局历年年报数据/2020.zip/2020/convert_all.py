# -*- coding: utf-8 -*-
"""批量转换2020全部篇目HTML为xlsx"""
import sys, os, re
sys.path.insert(0,'2020/scripts')
from html2xlsx_lib import *
from openpyxl import Workbook

NJ_TITLE = {
 '01':'综合','02':'国民经济核算','03':'人口、就业和工资','04':'价格指数','05':'人民生活',
 '06':'固定资产投资','07':'财政、金融','08':'对外经济贸易','09':'能源、资源、环境','10':'农业',
 '11':'工业','12':'建筑业','13':'运输、邮电和服务业','14':'批发零售、住宿餐饮和旅游','15':'科技、教育',
 '16':'文化、体育、卫生','17':'公共管理、社会保障和社会组织','18':'城市经济与建设','19':'区域经济',
 '20':'市县社会经济','21':'县(市)社会经济发展序列','23':'全国分省主要指标',
}

def conv_nj(njcode, outpath):
    # 收集该篇目所有子页面, 序列号排序
    pages=[]
    for f in os.listdir('2020/html'):
        m=re.match(rf'^nj{njcode}(\d+)\.htm$', f)
        if m: pages.append((int(m.group(1)), f))
    pages.sort(key=lambda x:(len(str(x[0])), x[0]))
    wb=Workbook(); wb.remove(wb.active)
    for seq,f in pages:
        if seq==0: continue  # 简要说明
        rows=read_cells(f'2020/html/{f}')
        title=sheet_title_for_page(rows,seq,njcode)
        if not title: continue
        title=re.sub(r'[]\\/*?:<>"|]','',title)[:31]
        ws=wb.create_sheet(title)
        write_sheet(ws,rows,njcode)
    # 若一个sheet都没有(如nj23附录特殊), 补个占位
    if len(wb.sheetnames)==0:
        wb.create_sheet('数据')
    wb.save(outpath)
    return wb.sheetnames

os.makedirs('2020',exist_ok=True)
report={}
for code,title in NJ_TITLE.items():
    try:
        names=conv_nj(code, f'2020/{title}.xlsx')
        report[title]=len(names)
        print(f"{title}: {len(names)} sheets")
    except Exception as e:
        report[title]=f"ERR {e}"
        print(f"{title}: ERROR {e}")
print("\n=== 完成 ===")
